# Пакет для selftest skill-audit.mjs

Один навык в папке skills/zipped-skill, лицензия — в корне пакета.
